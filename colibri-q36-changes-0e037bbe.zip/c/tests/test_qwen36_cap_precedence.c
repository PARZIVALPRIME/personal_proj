/* qwen36_cap_for_ram(): the cap<=0 ("auto") sentinel derives the expert-cache
 * slots/layer from host RAM instead of the old hardcoded default of 16
 * (bare CLI omission) / 16 (Segment API's memory_limit_bytes==0 fallback).
 * Pure function -- no Model*, no globals, no I/O -- same testability
 * contract as k3_cap_for_ram/coli_resolve_cap (test_k3_ram_budget.c,
 * test_cap_precedence.c). An explicit cap>0 never reaches this function at
 * all (main()/qwen36_segment_engine_open() only call it when cap<=0), so
 * "explicit cap always wins" is verified at the integration level
 * (test_qwen36_cap_budget.py), not here. Likewise, RAM_GB parsing itself
 * (getenv/atof) happens in model_init_range, not this function -- an
 * unparseable or negative RAM_GB reaches this function as ram_gb_override<=0
 * (atof's own behavior on garbage input), which is exactly what the
 * "override<=0 falls back to the computed budget" case below exercises. */
#define main qwen36_main_unused
#include "../qwen36.c"
#undef main

static int fails = 0;
#define CHECK(c) do { if (!(c)) { fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)

/* Roughly qwen36-i4-gs64 shape: hidden=2048 inter=512 n_experts=256. */
enum { HIDDEN = 2048, INTER = 512, N_EXPERTS = 256 };

int main(void) {
    /* RAM_GB override wins over the resident+avail*0.88 computed budget:
     * same resident/avail, only the override differs -> different cap. The
     * outparams (slot_gb, budget_gb) are threaded through rather than
     * recomputed by any caller, so budget_gb must equal the override
     * exactly when one is given. */
    {
        double slot_gb_a = 0, slot_gb_b = 0, budget_a = 0, budget_b = 0;
        int cap_computed = qwen36_cap_for_ram(4.83, 20.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, &slot_gb_a, &budget_a);
        int cap_override  = qwen36_cap_for_ram(4.83, 20.0, 64.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, &slot_gb_b, &budget_b);
        CHECK(cap_override > cap_computed);
        CHECK(slot_gb_a == slot_gb_b); /* override changes the budget, not the per-slot size */
        CHECK(budget_a == 4.83 + 20.0 * 0.88);
        CHECK(budget_b == 64.0);
    }

    /* A negative or zero override (e.g. RAM_GB unset, or set to garbage that
     * atof() parses as 0, or set to a negative number) is not an error --
     * it must fall back to the computed budget exactly as if RAM_GB had
     * never been read, not propagate a negative/zero budget. */
    {
        double budget_unset = 0, budget_negative = 0, budget_zero = 0;
        int cap_unset = qwen36_cap_for_ram(4.83, 20.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, &budget_unset);
        int cap_negative = qwen36_cap_for_ram(4.83, 20.0, -5.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, &budget_negative);
        int cap_zero = qwen36_cap_for_ram(4.83, 20.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, &budget_zero);
        CHECK(cap_unset == cap_negative && cap_unset == cap_zero);
        CHECK(budget_unset == budget_negative && budget_unset == budget_zero);
    }

    /* int4 (xf_mode) halves the per-slot byte cost of int8, so for identical
     * budget/geometry it derives a cap at least as large, strictly larger in
     * the constrained-budget middle of the range (not floored, not clamped
     * at n_experts on either side). */
    {
        double slot_gb_int8 = 0, slot_gb_int4 = 0;
        int cap_int8 = qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, &slot_gb_int8, NULL);
        int cap_int4 = qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 0, 0.0, &slot_gb_int4, NULL);
        CHECK(slot_gb_int4 < slot_gb_int8);
        CHECK(cap_int4 >= cap_int8);
        CHECK(cap_int4 > 1 && cap_int4 < N_EXPERTS);
        CHECK(cap_int8 > 1 && cap_int8 < N_EXPERTS);
        CHECK(cap_int4 > cap_int8);
    }

    /* A budget at or below the resident floor still returns a usable cap>=1
     * -- never 0, which would leave every layer's cache empty (expert_get
     * would then find no slot to evict and hang; see the comment above the
     * cap<0 CLI check in main()). */
    {
        int cap = qwen36_cap_for_ram(4.83, 0.0, 4.83, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, NULL);
        CHECK(cap == 1);
        int cap_neg_room = qwen36_cap_for_ram(4.83, 0.0, 1.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, NULL);
        CHECK(cap_neg_room == 1);
    }

    /* A huge budget clamps at n_experts, never runs past it. */
    {
        int cap = qwen36_cap_for_ram(4.83, 1000.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, NULL);
        CHECK(cap == N_EXPERTS);
    }

    /* n_active_layers scales the derived cap: the same total budget spread
     * over twice as many layers yields roughly half the per-layer slots
     * (Segment/Edge partial-model builds pass layer_end-layer_begin here,
     * not always the model's full n_layers). */
    {
        int cap_40 = qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, NULL);
        int cap_80 = qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 80, 0, 0, 0.0, NULL, NULL);
        CHECK(cap_80 < cap_40);
        CHECK(cap_80 >= cap_40 / 2 - 1 && cap_80 <= cap_40 / 2 + 1);
    }

    /* Degenerate inputs don't crash and still return a floored cap. */
    {
        CHECK(qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 0, 0, 0, 0.0, NULL, NULL) >= 1);
        CHECK(qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, -1, 0, 0, 0.0, NULL, NULL) >= 1);
        CHECK(qwen36_cap_for_ram(0.0, 0.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 0, 0, 0.0, NULL, NULL) >= 1);
    }

    /* The top-k floor: a 16 GB host with no room left after loading still gets
     * one token's routed experts per layer, not 1 slot (every token streamed its
     * 8 experts x 40 layers from disk), and the floor never exceeds n_experts. */
    {
        CHECK(qwen36_cap_for_ram(4.83, 0.0, 4.83, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 0.0, NULL, NULL) == 8);
        CHECK(qwen36_cap_for_ram(4.83, 0.0, 1.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 0.0, NULL, NULL) == 8);
        CHECK(qwen36_cap_for_ram(4.83, 0.0, 4.83, HIDDEN, INTER, 4, 40, 1, 8, 0.0, NULL, NULL) == 4);
        /* above the floor the floor changes nothing */
        int free_ = qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 0, 0.0, NULL, NULL);
        CHECK(free_ > 8);
        CHECK(qwen36_cap_for_ram(4.83, 3.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 0.0, NULL, NULL) == free_);
    }

    /* The KV reserve comes out of the room, not the budget: fewer slots, same
     * budget reported; a reserve larger than the room falls to the floor; a
     * negative reserve is ignored. */
    {
        double b0 = 0, b1 = 0;
        int no_kv = qwen36_cap_for_ram(4.83, 6.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 0.0, NULL, &b0);
        int kv = qwen36_cap_for_ram(4.83, 6.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 0.65, NULL, &b1);
        CHECK(kv < no_kv && kv >= 8);
        CHECK(b0 == b1);
        CHECK(qwen36_cap_for_ram(4.83, 6.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, 100.0, NULL, NULL) == 8);
        CHECK(qwen36_cap_for_ram(4.83, 6.0, 0.0, HIDDEN, INTER, N_EXPERTS, 40, 1, 8, -3.0, NULL, NULL) == no_kv);
    }

    /* q36_kv_reserve_gb: K and V of every attention layer in the range at the
     * context ceiling; DeltaNet layers hold none; a sliding-window layer holds
     * its ring when that is shorter than the context. */
    {
        Cfg c; memset(&c, 0, sizeof c);
        uint8_t attn[8] = {0, 0, 0, 1, 0, 0, 0, 1};
        c.n_layers = 8; c.is_attn = attn; c.kv_heads = 2; c.k_head_dim = 256;
        double one = 2.0 * 2 * 32768.0 * 256 * 2 / 1073741824.0;   /* f16, one layer */
        double all = q36_kv_reserve_gb(&c, 0, 8, 32768, 2);
        CHECK(all > 2 * one - 1e-9 && all < 2 * one + 1e-9);
        double half = q36_kv_reserve_gb(&c, 0, 4, 32768, 2);
        CHECK(half > one - 1e-9 && half < one + 1e-9);
        CHECK(q36_kv_reserve_gb(&c, 0, 3, 32768, 2) == 0.0);
        CHECK(q36_kv_reserve_gb(&c, 0, 8, 32768, 4) > all * 2 - 1e-9);
        CHECK(q36_kv_reserve_gb(&c, 0, 8, 0, 2) == 0.0);
        CHECK(q36_kv_reserve_gb(NULL, 0, 8, 32768, 2) == 0.0);
        uint8_t win[8] = {0, 0, 0, 1, 0, 0, 0, 0};
        c.win_layer = win; c.window = 1024;
        unsetenv("Q36_KV_RING");
        double ringed = q36_kv_reserve_gb(&c, 0, 8, 32768, 2);
        CHECK(ringed < all && ringed > one);
    }

    /* qwen36_resolved_cap: the sentinel must never leave main() unresolved.
     *
     * model_init_range resolves cap<=0 into its own local copy and writes the
     * result to every layer's cache; main()'s variable keeps the sentinel.
     * qt_init refuses the VRAM expert tier for any cap != n_experts outside
     * fp8-stream mode, so handing it the unresolved 0 switched the tier off
     * under COLI_CUDA=1 even when auto-sizing had picked every expert. Found by
     * review on #1747, not by a run: the guard lives behind COLI_CUDA and the
     * CPU build links the inline stub, so no CPU-only test can observe it. */
    {
        LCache cache[2];
        cache[0].cap = N_EXPERTS; cache[1].cap = N_EXPERTS;

        /* the sentinel resolves to what model_init_range stored */
        CHECK(qwen36_resolved_cap(0, cache, 2) == N_EXPERTS);
        CHECK(qwen36_resolved_cap(-1, cache, 2) == N_EXPERTS);

        /* an explicit cap is passed through untouched -- the byte-identical
         * guarantee for existing invocations (#1747's first fixed decision) */
        CHECK(qwen36_resolved_cap(4, cache, 2) == 4);
        CHECK(qwen36_resolved_cap(N_EXPERTS, cache, 2) == N_EXPERTS);

        /* degenerate: nothing to read back, hand the sentinel on unchanged
         * rather than invent a value or dereference a null cache */
        CHECK(qwen36_resolved_cap(0, NULL, 2) == 0);
        CHECK(qwen36_resolved_cap(0, cache, 0) == 0);
    }

    printf(fails ? "test_qwen36_cap_precedence: FAIL (%d)\n" : "test_qwen36_cap_precedence: PASS\n", fails);
    return fails != 0;
}
